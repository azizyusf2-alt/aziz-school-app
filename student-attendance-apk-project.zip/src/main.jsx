import React,{useEffect,useMemo,useState} from "react";
import {createRoot} from "react-dom/client";
import {jsPDF} from "jspdf";
import "./style.css";

const KEY="student_school_app_v1";
const initial={branches:[{id:"basic-a",cat:"بنەڕەتی",name:"A",students:[]},{id:"basic-b",cat:"بنەڕەتی",name:"B",students:[]}],attendance:{},grades:{}};
function load(){try{return JSON.parse(localStorage.getItem(KEY))||initial}catch{return initial}}
function App(){
 const [data,setData]=useState(load),[tab,setTab]=useState("attendance"),[date,setDate]=useState(new Date().toISOString().slice(0,10)),[branch,setBranch]=useState("basic-a"),[showAdd,setShowAdd]=useState(false),[student,setStudent]=useState({name:"",id:""});
 useEffect(()=>localStorage.setItem(KEY,JSON.stringify(data)),[data]);
 const br=data.branches.find(x=>x.id===branch)||data.branches[0];
 const students=br?.students||[];
 const statuses=data.attendance[date]?.[branch]||{};
 const setStatus=(sid,status)=>setData(d=>({...d,attendance:{...d.attendance,[date]:{...(d.attendance[date]||{}),[branch]:{...(d.attendance[date]?.[branch]||{}),[sid]:status}}}}));
 const addStudent=()=>{if(!student.name.trim())return;setData(d=>({...d,branches:d.branches.map(b=>b.id===branch?{...b,students:[...b.students,{id:crypto.randomUUID(),name:student.name.trim(),number:student.id.trim()}]}:b)}));setStudent({name:"",id:""});setShowAdd(false)};
 const del=(sid)=>{if(!confirm("دڵنیایت لە سڕینەوەی قوتابی؟"))return;setData(d=>({...d,branches:d.branches.map(b=>b.id===branch?{...b,students:b.students.filter(s=>s.id!==sid)}:b)}))};
 const exportData=()=>{const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:"application/json"}));a.download="school-backup.json";a.click()};
 const restore=e=>{const f=e.target.files?.[0];if(!f)return;const r=new FileReader();r.onload=()=>{try{setData(JSON.parse(r.result));alert("داتا بە سەرکەوتوویی گەڕێندرایەوە")}catch{alert("فایلی JSON دروست نییە")}};r.readAsText(f)};
 const pdf=()=>{const doc=new jsPDF();doc.setFontSize(16);doc.text("Student Attendance Report",20,20);doc.setFontSize(11);doc.text(`Date: ${date}`,20,30);doc.text(`Branch: ${br?.name||""}`,20,38);students.forEach((s,i)=>doc.text(`${i+1}. ${s.name} - ${statuses[s.id]||"ئامادە دیاری نەکراوە"}`,20,50+i*8));doc.save(`attendance-${date}.pdf`)};
 const counts=useMemo(()=>({present:students.filter(s=>statuses[s.id]==="present").length,absent:students.filter(s=>statuses[s.id]==="absent").length,excused:students.filter(s=>statuses[s.id]==="excused").length}),[students,statuses]);
 return <div className="app">
  <header><div><div className="eyebrow">School Management</div><h1>ئامادەبوون و نمرە</h1></div><div className="badge">Offline</div></header>
  <main>
   {tab==="attendance"&&<section>
    <div className="toolbar"><div><label>بەروار</label><input type="date" value={date} onChange={e=>setDate(e.target.value)}/></div><div><label>لق</label><select value={branch} onChange={e=>setBranch(e.target.value)}>{data.branches.map(b=><option key={b.id} value={b.id}>{b.cat} - {b.name}</option>)}</select></div></div>
    <div className="stats"><div><b>{counts.present}</b><span>ئامادە</span></div><div><b>{counts.absent}</b><span>غیاب</span></div><div><b>{counts.excused}</b><span>مۆڵەت</span></div><div><b>{students.length}</b><span>کۆی گشتی</span></div></div>
    <div className="card"><div className="cardhead"><div><h2>تۆماری ئامادەبوون</h2><small>{br?.cat} / {br?.name}</small></div><button className="primary" onClick={()=>setShowAdd(true)}>+ قوتابی نوێ</button></div>
     {students.length===0?<div className="empty">هیچ قوتابییەک لەم لقەدا نییە.</div>:students.map(s=><div className="studentrow" key={s.id}><div className="avatar">{s.name[0]}</div><div className="sinfo"><b>{s.name}</b><small>{s.number||"بێ ژمارە"}</small></div><div className="actions"><button className={statuses[s.id]==="present"?"on present":""} onClick={()=>setStatus(s.id,"present")}>ئامادە</button><button className={statuses[s.id]==="absent"?"on absent":""} onClick={()=>setStatus(s.id,"absent")}>غیاب</button><button className={statuses[s.id]==="excused"?"on excused":""} onClick={()=>setStatus(s.id,"excused")}>مۆڵەت</button><button className="icon" onClick={()=>del(s.id)}>×</button></div></div>)}
    </div>
   </section>}
   {tab==="reports"&&<section><div className="pageTitle"><h2>نمرە و ڕاپۆرت</h2><p>ڕاپۆرتی ئامادەبوون و نمرەکان.</p></div><div className="grid"><div className="card"><h3>ڕاپۆرتی ڕۆژانە</h3><p>بەروار: {date}</p><button className="primary" onClick={pdf}>دابەزاندن بە PDF</button></div><div className="card"><h3>بەشی نمرەکان</h3><p>نمرەی مانگانە، Quiz و بەشداری.</p><button disabled className="secondary">بەم زووانە</button></div></div></section>}
   {tab==="students"&&<section><div className="pageTitle"><h2>قوتابیان</h2><p>بەڕێوەبردنی زانستی، وێژەیی و بنەڕەتی.</p></div><div className="card"><div className="branchbar">{["زانستی","وێژەیی","بنەڕەتی"].map(c=><span key={c}>{c}</span>)}<button className="secondary" onClick={()=>{const n=prompt("ناوی لق");if(n)setData(d=>({...d,branches:[...d.branches,{id:crypto.randomUUID(),cat:"بنەڕەتی",name:n,students:[]}]}))}}>+ زیادکردنی لق</button></div>{data.branches.map(b=><div className={"branch "+(b.id===branch?"selected":"")} key={b.id} onClick={()=>setBranch(b.id)}><b>{b.cat} - {b.name}</b><span>{b.students.length} قوتابی</span></div>)}</div></section>}
   {tab==="data"&&<section><div className="pageTitle"><h2>داتا و دەربارە</h2></div><div className="card about"><h3>ئەم بەرنامەیە لەلایەن م. عزیز یوڕف دروستکراوە</h3><p>داتاکانت لە ناوخۆی ئامێرەکەت هەڵدەگیرێن و بێ ئینتەرنێتیش کار دەکات.</p><div className="row"><button className="primary" onClick={exportData}>دەرهێنانی داتا</button><label className="secondary file">گەڕاندنەوەی داتا<input type="file" accept=".json" onChange={restore}/></label></div><hr/><h3>ڕێنمایی</h3><ol><li>لە قوتابیان لقێک هەڵبژێرە و قوتابی زیاد بکە.</li><li>لە تۆماری ئامادەبوون بەروار دیاری بکە.</li><li>دۆخی هەر قوتابییەک هەڵبژێرە؛ خۆکارانە پاشەکەوت دەکرێت.</li><li>بۆ پاراستنی داتا بەردەوام Backup ـی JSON وەربگرە.</li></ol></div></section>}
  </main>
  <nav>{[["attendance","▣","ئامادەبوون"],["reports","▥","نمرە و ڕاپۆرت"],["students","♙","قوتابیان"],["data","⚙","داتا و دەربارە"]].map(([k,i,t])=><button className={tab===k?"active":""} onClick={()=>setTab(k)} key={k}><i>{i}</i><span>{t}</span></button>)}</nav>
  {showAdd&&<div className="modal"><div className="modalbox"><h2>زیادکردنی قوتابی</h2><input autoFocus placeholder="ناوی قوتابی" value={student.name} onChange={e=>setStudent({...student,name:e.target.value})}/><input placeholder="ژمارەی قوتابی (ئارەزوومەندانە)" value={student.id} onChange={e=>setStudent({...student,id:e.target.value})}/><div className="row"><button className="primary" onClick={addStudent}>زیادکردن</button><button className="secondary" onClick={()=>setShowAdd(false)}>پاشگەزبوونەوە</button></div></div></div>}
 </div>
}
createRoot(document.getElementById("root")).render(<App/>);
