# Student Attendance & Grades APK Project
ئەم وەشانە MVP ـی یەکەمی ئەپی Android ـە: RTL، قوتابی/لق، ئامادەبوونی ڕۆژانە، backup/restore JSON و PDF.
## Build
1. Node.js 20+ دابەزێنە.
2. `npm install`
3. `npm run build`
4. بۆ APK، Capacitor زیاد بکە و Android Studio بەکاربهێنە:
`npm install @capacitor/core @capacitor/cli @capacitor/android`
`npx cap init "ئامادەبوون و نمرە" "com.azizyusuf.attendance" --web-dir=dist`
`npx cap add android`
`npm run build && npx cap sync android`
`npx cap open android`
لە Android Studio: Build > Generate Signed Bundle / APK > APK.
